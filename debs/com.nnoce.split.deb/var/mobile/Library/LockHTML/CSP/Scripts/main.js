window.addEventListener("load", function() { 
   document.body.style.width='100%';
   document.body.style.height='100%';
}, false);

var shortdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

function loadClock() {
    clock({
        twentyfour: false,
        padzero: false,
        refresh: 5000,
        success: function(clock) {
            document.getElementById('day').innerHTML = shortdays[clock.day()];
            document.getElementById('date').innerHTML = (clock.date() < 10) ? "0" + clock.date() : clock.date();
            document.getElementById('time').innerHTML = clock.hour() + ":" + clock.minute();
        }
    });
}

function init(){
loadClock();
setInterval("loadClock();", 1000);
}




